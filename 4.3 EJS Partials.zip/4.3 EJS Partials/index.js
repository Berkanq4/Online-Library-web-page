import express from 'express';
import axios from 'axios';
import bcrypt from 'bcrypt';
import cron from 'node-cron';
import session from 'express-session';
import dotenv from 'dotenv';
import mysql from 'mysql2';
import nodemailer from "nodemailer";
import bodyParser from 'body-parser';

dotenv.config();

const app = express();
const port = process.env.PORT || 3000;

// MySQL setup
const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'your-database password',
  database: 'library2'
});

connection.connect(err => {
  if (err) throw err;
  console.log('Connected to MySQL database');
});

// Middleware
app.use(express.static('public'));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(session({
  secret: process.env.SESSION_SECRET || 'your-secret-key',
  resave: false,
  saveUninitialized: true,
  cookie: { secure: process.env.NODE_ENV === 'production' },
}));

// Authentication Middleware
const isAuthenticated = (req, res, next) => {
  if (!req.session.userId) return res.status(401).send('You need to log in');
  next();
};

// Middleware to parse form data
app.use(bodyParser.urlencoded({ extended: false }));

// Create a transporter object with your email service's SMTP settings
const transporter = nodemailer.createTransport({
  service: 'gmail', // For example, Gmail. Replace with your email service if different.
  auth: {
    user: 'your-email', // Your email address
    pass: 'yourpassword'   // Your email password or app password
  }
});

// Handle POST requests to /send-email
app.post('/send-email', (req, res) => {
  const { name, email, text } = req.body;

  const mailOptions = {
    from: email, // Sender address
    to: 'youremail', // List of recipients
    subject: `Contact Form Submission from ${name}`,
    text: text
  };

  transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
      return res.status(500).send('There was an error sending the email.');
    }
    res.send('Email sent successfully!');
  });
});

app.post('/register', async (req, res) => {
  const { username, password } = req.body;
  console.log('Received registration request:', { username, password });

  if (!username || !password) {
    return res.status(400).send('Username and password are required');
  }

  try {
    const [existingUser] = await connection.promise().query('SELECT * FROM users WHERE username = ?', [username]);
    if (existingUser.length > 0) {
      return res.status(400).send('Username already exists');
    }

    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    await connection.promise().query('INSERT INTO users (username, password) VALUES (?, ?)', [username, hashedPassword]);
    res.status(201).send('User registered successfully');
  } catch (error) {
    console.error('Error during registration:', error);
    res.status(500).send('Error registering user');
  }
});


app.post('/login', async (req, res) => {
  const { username, password } = req.body;

  if (!username || !password) {
    return res.status(400).send('Username and password are required');
  }

  try {
    const [user] = await connection.promise().query('SELECT * FROM users WHERE username = ?', [username]);
    if (user.length === 0) {
      return res.status(400).send('Invalid username or password');
    }

    const isMatch = await bcrypt.compare(password, user[0].password);
    if (!isMatch) {
      return res.status(400).send('Invalid username or password');
    }

    req.session.userId = user[0].id;
    req.session.save(err => {
      if (err) {
        console.error('Session save error:', err);
        return res.status(500).send('Error logging in');
      }
      res.status(200).send('Logged in successfully');
    });
  } catch (error) {
    console.error('Error during login:', error);
    res.status(500).send('Error logging in');
  }
});

app.post('/logout', (req, res) => {
  req.session.destroy(err => {
    if (err) return res.status(500).send('Error logging out');
    res.status(200).send('Logged out successfully');
  });
});

app.post('/borrow', async (req, res) => {
  console.log("Received borrow request:", req.body.books);
  const books  = req.body.books;
  // Assuming you have a function to handle borrowing books
  books.forEach(book => {
    console.log(`Processing book: ${book.bookId}, ${book.title}, ${book.author}`);
    // Perform database operations here, such as inserting into a "borrowed_books" table
    // Example: saveBorrowedBook(book.bookId, book.title, book.author);
  });
  const userId = req.session.userId;

  if (!Array.isArray(books)) {
    return res.status(400).send('Invalid books array');
  }

  try {
    const [[user]] = await connection.promise().query('SELECT * FROM users WHERE id = ?', [userId]);
    if (!user) return res.status(401).send('User not found');

    if (user.borrowed_count + books.length > 5) {
      return res.status(403).send('You have reached your borrowing limit for this month');
    }

    const currentDate = new Date();
    const nextMonthDate = new Date();
    nextMonthDate.setMonth(currentDate.getMonth() + 1);

    for (let book of books) {
      const { bookId, title, author } = book;

      console.log(`Processing book: ${bookId}, ${title}, ${author}`);
      
      const [[existingBook]] = await connection.promise().query('SELECT * FROM books WHERE id = ?', [bookId]);
      
      if (existingBook) {
        await connection.promise().query('UPDATE books SET title = ?, author = ?, borrow_count = borrow_count + 1 WHERE id = ?', [title, author, bookId]);
      } else {
        await connection.promise().query('INSERT INTO books (id, title, author, borrow_count) VALUES (?, ?, ?, ?)', [bookId, title, author, 1]);
      }

      await connection.promise().query('INSERT INTO borrowed_books (user_id, book_id, borrow_date, due_date) VALUES (?, ?, ?, ?)', [userId, bookId, currentDate, nextMonthDate]);
    }

    await connection.promise().query('UPDATE users SET borrowed_count = borrowed_count + ? WHERE id = ?', [books.length, userId]);

    res.status(200).send('Books borrowed successfully');
  } catch (error) {
    console.error('Error borrowing books:', error);
    res.status(500).send('Error borrowing books');
  }
});






// Top 5 Most Popular Books Route
app.get('/top-books', async (req, res) => {
  try {
    const [topBooks] = await connection.promise().query('SELECT * FROM books ORDER BY borrow_count DESC LIMIT 5');
    res.json(topBooks);
  } catch (error) {
    console.error('Error fetching top books:', error);
    res.status(500).json({ error: 'Error fetching top books' });
  }
});

app.get('/profileInfo', isAuthenticated, async (req, res) => {
  try {
    const userId = req.session.userId;
    const [[user]] = await connection.promise().query('SELECT * FROM users WHERE id = ?', [userId]);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    const [borrowedBooks] = await connection.promise().query(
      `SELECT books.id, books.title, books.author, borrowed_books.borrow_date, borrowed_books.due_date
       FROM borrowed_books
       JOIN books ON borrowed_books.book_id = books.id
       WHERE borrowed_books.user_id = ?`,
      [userId]
    );
   
    res.json({
      username: user.username,
      accountCreationDate: new Date(user.id * 1000).toISOString(),
      borrowedBooks
    });
  } catch (error) {
    console.error('Error fetching profile data:', error);
    res.status(500).json({ error: 'Error fetching profile data' });
  }
});


// Search Endpoint
app.get('/search', async (req, res) => {
  const query = req.query.q;
  const url = `https://openlibrary.org/search.json?q=${encodeURIComponent(query)}`;

  try {
    const response = await axios.get(url);
    const books = response.data.docs.map(book => ({
      id: book.key,
      title: book.title,
      author: book.author_name ? book.author_name.join(', ') : 'Unknown Author'
    }));

    res.json(books);
  } catch (error) {
    console.error('Error fetching data:', error);
    res.status(500).json({ error: 'Error fetching data' });
  }
});



// Cron Job to Reset Borrow Count Monthly
cron.schedule('0 0 1 * *', async () => {
  try {
    await connection.promise().query('UPDATE users SET borrowed_count = 0');
    console.log('Borrow counts reset for all users');
  } catch (error) {
    console.error('Error resetting borrow counts:', error);
  }
});

// Routes to Render Pages
app.get("/", (req, res) => {
  res.render("index.ejs");
});

app.get("/register", (req, res) => {
  res.render("register.ejs");
});

app.get("/profile", (req, res) => {
  res.render("profile.ejs");
});

app.get("/login", (req, res) => {
  res.render("login.ejs");
});

app.get("/about", (req, res) => {
  res.render("about.ejs");
});

app.get("/contact", (req, res) => {
  res.render("contact.ejs");
});

// Start Server
app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
